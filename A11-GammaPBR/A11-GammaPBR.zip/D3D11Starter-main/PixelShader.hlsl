#include "ShaderInclusions.hlsli"

cbuffer DataFromCPU : register(b0)
{
    Light lights[5];
    float4 colorTint;
    float4 ambientColor;
    float2 totalTime;
    float2 scale;
    float2 offset;
    float2 padding;
    float3 cameraPos;
}

// PBR textures
Texture2D albedo : register(t0);
Texture2D NormalMap : register(t1);
Texture2D RoughnessMap : register(t2);
Texture2D MetalnessMap : register(t3);

// Sampler states
SamplerState BasicSampler : register(s0);

// --------------------------------------------------------
// The entry point (main method) for our pixel shader
// 
// - Input is the data coming down the pipeline (defined by the struct)
// - Output is a single color (float4)
// - Has a special semantic (SV_TARGET), which means 
//    "put the output of this into the current render target"
// - Named "main" because that's the default the shader compiler looks for
// --------------------------------------------------------
float4 main(VertexToPixel input) : SV_TARGET
{
    // normalizing input normals/tangents
    input.normal = normalize(input.normal);
    input.tangent = normalize(input.tangent);
    
    // Unpacking/sampling normal
    float3 unpackedNormal = normalize(NormalMap.Sample(BasicSampler, (input.uv * scale + offset)).rgb * 2.0f - 1.0f);
    
    // Creating matrix
    float3 N = normalize(input.normal);
    float3 T = normalize(input.tangent - dot(input.tangent, N) * N);
    float3 B = cross(T, N);
    float3x3 TBN = float3x3(T, B, N);
    
    input.normal = normalize(mul(unpackedNormal, TBN));
    
    // Sampling albedo
    float4 surfaceColor = albedo.Sample(BasicSampler, (input.uv * scale + offset));
    
    //gamma corecting (maybe want to color tint after this?)
    surfaceColor.rgb = pow(surfaceColor.rgb, 2.2f);
    
    // applying color tint
    surfaceColor *= colorTint;
    
    // Sampling roughness
    float roughness = RoughnessMap.Sample(BasicSampler, input.uv).r;
    
    // Sampling metalness
    float metalness = MetalnessMap.Sample(BasicSampler, input.uv).r;
    
    // Specular color calculation
    float3 specularColor = lerp(float3(0.04f, 0.04f, 0.04f), surfaceColor.rgb, metalness);
    
    // applying ambient light and color tint to surface color
    //float4 totalLight = surfaceColor * (ambientColor * (1 - metalness));
    float4 totalLight = 0;
   
    // Adding together all lights in the scene
    // need to make sure to update this value when changed elsewhere
    for (int i = 0; i < 5; i++)
    {
        switch (lights[i].Type)
        {
            case LIGHT_TYPE_DIRECTIONAL:
                totalLight += directionalLight(surfaceColor, input.normal, lights[i], cameraPos, input.worldPosition, roughness, specularColor, metalness);
                break;
            case LIGHT_TYPE_POINT:
                totalLight += pointLight(surfaceColor, input.normal, lights[i], cameraPos, input.worldPosition, roughness, specularColor, metalness);
                break;
            case LIGHT_TYPE_SPOT:
                totalLight += spotLight(surfaceColor, input.normal, lights[i], cameraPos, input.worldPosition, roughness, specularColor, metalness);
                break;
        }
        
    }
    
    // Return final surface color with all applied lights
    
    float4 gammaAdjustedColor = pow(totalLight, (1.0f / 2.2f));
    return float4(gammaAdjustedColor.xyz, 1);
    //return float4(totalLight.xyz, 1);
    
    //return surfaceColor
    //return specularColor.xyzz;
    //return metalness;
}