#include "Game.h"
#include "Graphics.h"
#include "Vertex.h"
#include "Input.h"
#include "PathHelpers.h"
#include "Window.h"
#include "Mesh.h"
#include "BufferStructs.h"

#include <DirectXMath.h>
#include <vector>
#include <string>

// This code assumes files are in "ImGui" subfolder!
// Adjust as necessary for your own folder structure and project setup
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_dx11.h"
#include "ImGui/imgui_impl_win32.h"

// Needed for a helper function to load pre-compiled shader files
#pragma comment(lib, "d3dcompiler.lib")
#include <d3dcompiler.h>

// For the DirectX Math library
using namespace DirectX;

// --------------------------------------------------------
// The constructor is called after the window and graphics API
// are initialized but before the game loop begins
// --------------------------------------------------------
Game::Game()
{
	// Helper methods for loading shaders, creating some basic
	// geometry to draw and some simple camera matrices.
	//  - You'll be expanding and/or replacing these later
	LoadShaders();
	CreateGeometry();

	// Initialize ImGui itself & platform/renderer backends
	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGui_ImplWin32_Init(Window::Handle());
	ImGui_ImplDX11_Init(Graphics::Device.Get(), Graphics::Context.Get());

	// Pick a style (uncomment one of these 3)
	ImGui::StyleColorsDark();
	//ImGui::StyleColorsLight();
	//ImGui::StyleColorsClassic()

	// Set initial graphics API state
	//  - These settings persist until we change them
	//  - Some of these, like the primitive topology & input layout, probably won't change
	//  - Others, like setting shaders, will need to be moved elsewhere later
	{
		// Tell the input assembler (IA) stage of the pipeline what kind of
		// geometric primitives (points, lines or triangles) we want to draw.  
		// Essentially: "What kind of shape should the GPU draw with our vertices?"
		Graphics::Context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

		// Ensure the pipeline knows how to interpret all the numbers stored in
		// the vertex buffer. For this course, all of your vertices will probably
		// have the same layout, so we can just set this once at startup.
		Graphics::Context->IASetInputLayout(inputLayout.Get());

		// Set the active vertex and pixel shaders
		//  - Once you start applying different shaders to different objects,
		//    these calls will need to happen multiple times per frame
		Graphics::Context->VSSetShader(vertexShader.Get(), 0, 0);
		Graphics::Context->PSSetShader(pixelShader.Get(), 0, 0);
	}

	// Creating buffer size
	int size = sizeof(VertexShaderData);
	size = (size + 15) / 16 * 16;

	// Defining buffer settings
	D3D11_BUFFER_DESC cbDesc{};
	cbDesc.Usage = D3D11_USAGE_DYNAMIC;
	cbDesc.ByteWidth = size;
	cbDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	cbDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	cbDesc.MiscFlags = 0;
	cbDesc.StructureByteStride = 0;

	// Actually creating buffer
	Graphics::Device->CreateBuffer(&cbDesc, 0, constantBuffer.GetAddressOf());

	// Binding constant buffer to pipeline stage
	Graphics::Context->VSSetConstantBuffers(0, 1, constantBuffer.GetAddressOf());
}


// --------------------------------------------------------
// Clean up memory or objects created by this class
// 
// Note: Using smart pointers means there probably won't
//       be much to manually clean up here!
// --------------------------------------------------------
Game::~Game()
{
	ImGui_ImplDX11_Shutdown();
	ImGui_ImplWin32_Shutdown();
	ImGui::DestroyContext();
}


// --------------------------------------------------------
// Loads shaders from compiled shader object (.cso) files
// and also created the Input Layout that describes our 
// vertex data to the rendering pipeline. 
// - Input Layout creation is done here because it must 
//    be verified against vertex shader byte code
// - We'll have that byte code already loaded below
// --------------------------------------------------------
void Game::LoadShaders()
{
	// BLOBs (or Binary Large OBjects) for reading raw data from external files
	// - This is a simplified way of handling big chunks of external data
	// - Literally just a big array of bytes read from a file
	ID3DBlob* pixelShaderBlob;
	ID3DBlob* vertexShaderBlob;

	// Loading shaders
	//  - Visual Studio will compile our shaders at build time
	//  - They are saved as .cso (Compiled Shader Object) files
	//  - We need to load them when the application starts
	{
		// Read our compiled shader code files into blobs
		// - Essentially just "open the file and plop its contents here"
		// - Uses the custom FixPath() helper from Helpers.h to ensure relative paths
		// - Note the "L" before the string - this tells the compiler the string uses wide characters
		D3DReadFileToBlob(FixPath(L"PixelShader.cso").c_str(), &pixelShaderBlob);
		D3DReadFileToBlob(FixPath(L"VertexShader.cso").c_str(), &vertexShaderBlob);

		// Create the actual Direct3D shaders on the GPU
		Graphics::Device->CreatePixelShader(
			pixelShaderBlob->GetBufferPointer(),	// Pointer to blob's contents
			pixelShaderBlob->GetBufferSize(),		// How big is that data?
			0,										// No classes in this shader
			pixelShader.GetAddressOf());			// Address of the ID3D11PixelShader pointer

		Graphics::Device->CreateVertexShader(
			vertexShaderBlob->GetBufferPointer(),	// Get a pointer to the blob's contents
			vertexShaderBlob->GetBufferSize(),		// How big is that data?
			0,										// No classes in this shader
			vertexShader.GetAddressOf());			// The address of the ID3D11VertexShader pointer
	}

	// Create an input layout 
	//  - This describes the layout of data sent to a vertex shader
	//  - In other words, it describes how to interpret data (numbers) in a vertex buffer
	//  - Doing this NOW because it requires a vertex shader's byte code to verify against!
	//  - Luckily, we already have that loaded (the vertex shader blob above)
	{
		D3D11_INPUT_ELEMENT_DESC inputElements[2] = {};

		// Set up the first element - a position, which is 3 float values
		inputElements[0].Format = DXGI_FORMAT_R32G32B32_FLOAT;				// Most formats are described as color channels; really it just means "Three 32-bit floats"
		inputElements[0].SemanticName = "POSITION";							// This is "POSITION" - needs to match the semantics in our vertex shader input!
		inputElements[0].AlignedByteOffset = D3D11_APPEND_ALIGNED_ELEMENT;	// How far into the vertex is this?  Assume it's after the previous element

		// Set up the second element - a color, which is 4 more float values
		inputElements[1].Format = DXGI_FORMAT_R32G32B32A32_FLOAT;			// 4x 32-bit floats
		inputElements[1].SemanticName = "COLOR";							// Match our vertex shader input!
		inputElements[1].AlignedByteOffset = D3D11_APPEND_ALIGNED_ELEMENT;	// After the previous element

		// Create the input layout, verifying our description against actual shader code
		Graphics::Device->CreateInputLayout(
			inputElements,							// An array of descriptions
			2,										// How many elements in that array?
			vertexShaderBlob->GetBufferPointer(),	// Pointer to the code of a shader that uses this layout
			vertexShaderBlob->GetBufferSize(),		// Size of the shader code that uses this layout
			inputLayout.GetAddressOf());			// Address of the resulting ID3D11InputLayout pointer
	}
}


// --------------------------------------------------------
// Creates the geometry we're going to draw
// --------------------------------------------------------
void Game::CreateGeometry()
{
	// Create some temporary variables to represent colors
	// - Not necessary, just makes things more readable
	XMFLOAT4 red = XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f);
	XMFLOAT4 green = XMFLOAT4(0.0f, 1.0f, 0.0f, 1.0f);
	XMFLOAT4 blue = XMFLOAT4(0.0f, 0.0f, 1.0f, 1.0f);

	// First mesh vertices and indices
	Vertex meshOneVertices[] =
	{
		{ XMFLOAT3(+0.0f, +0.5f, +0.0f), red },
		{ XMFLOAT3(+0.5f, -0.5f, +0.0f), blue },
		{ XMFLOAT3(-0.5f, -0.5f, +0.0f), green },
	};
	int meshOneIndices[] = { 0, 1, 2 };

	// Second mesh vertices and indices
	Vertex meshTwoVertices[] =
	{
		{ XMFLOAT3(+0.7f, +0.7f, +0.0f), red },
		{ XMFLOAT3(+0.7f, +0.5f, +0.0f), red },
		{ XMFLOAT3(+0.5f, +0.5f, +0.0f), green },
		{ XMFLOAT3(+0.5f, +0.7f, +0.0f), green },
	};
	int meshTwoIndices[] = { 0, 1, 2, 0, 2, 3  };

	// Third mesh vertices and indices
	Vertex meshThreeVertices[] = 
	{
		{ XMFLOAT3(-0.9f, -0.9f, +0.0f), blue },
		{ XMFLOAT3(-0.7f, -0.7f, +0.0f), green },
		{ XMFLOAT3(-0.7f, -0.9f, +0.0f), green },
		{ XMFLOAT3(-0.4f, -0.7f, +0.0f), green },
		{ XMFLOAT3(-0.7f, -0.3f, +0.0f), blue },
	};
	int meshThreeIndices[] = { 0, 1, 2, 3, 2, 1, 4, 3, 1 };

	// Creating new Mesh instances and adding them to storage vector
	// probably not best practice to hard code their vertex and index count
	meshes.push_back(std::make_shared<Mesh>("Triangle", meshOneVertices, 3, meshOneIndices, 3));
	meshes.push_back(std::make_shared<Mesh>("Square", meshTwoVertices, 4, meshTwoIndices, 6));
	meshes.push_back(std::make_shared<Mesh>("Other", meshThreeVertices, 5, meshThreeIndices, 9));

	// adding game entities
	gameEntities.push_back(std::make_shared<GameEntity>(std::make_shared<Mesh>("Other", meshThreeVertices, 5, meshThreeIndices, 9)));
	gameEntities.push_back(std::make_shared<GameEntity>(std::make_shared<Mesh>("Other", meshThreeVertices, 5, meshThreeIndices, 9)));
	gameEntities.push_back(std::make_shared<GameEntity>(std::make_shared<Mesh>("Other", meshThreeVertices, 5, meshThreeIndices, 9)));
	gameEntities.push_back(std::make_shared<GameEntity>(std::make_shared<Mesh>("Square", meshTwoVertices, 4, meshTwoIndices, 6)));
	gameEntities.push_back(std::make_shared<GameEntity>(std::make_shared<Mesh>("Triangle", meshOneVertices, 3, meshOneIndices, 3)));
}


// --------------------------------------------------------
// Handle resizing to match the new window size
//  - Eventually, we'll want to update our 3D camera
// --------------------------------------------------------
void Game::OnResize()
{
	
}


// --------------------------------------------------------
// Update your game here - user input, move objects, AI, etc.
// --------------------------------------------------------
void Game::Update(float deltaTime, float totalTime)
{
	Game::ImGuiUpdate(deltaTime);

	gameEntities[0]->GetTransform()->SetPosition(sinf(totalTime), 0, 0);
	gameEntities[1]->GetTransform()->SetRotation(0, 0, totalTime);
	gameEntities[2]->GetTransform()->SetScale(sinf(totalTime),sinf(totalTime),0);

	// Example input checking: Quit if the escape key is pressed
	if (Input::KeyDown(VK_ESCAPE))
		Window::Quit();
}

void Game::ImGuiUpdate(float deltaTime)
{
	// Put this all in a helper method that is called from Game::Update()
	// Feed fresh data to ImGui
	ImGuiIO & io = ImGui::GetIO();
	io.DeltaTime = deltaTime;
	io.DisplaySize.x = (float)Window::Width();
	io.DisplaySize.y = (float)Window::Height();

	// Reset the frame
	ImGui_ImplDX11_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();

	// Determine new input capture
	Input::SetKeyboardCapture(io.WantCaptureKeyboard);
	Input::SetMouseCapture(io.WantCaptureMouse);

	// Show the demo window
	//ImGui::ShowDemoWindow();

	// Create custom ImGui window
	ImGui::Begin("My Cool Window");

	// Assignment 2 UI components
	if(ImGui::CollapsingHeader("Window Info/Misc")) {
		// Framerate & Window res
		ImGui::Text("Framerate: %f fps", ImGui::GetIO().Framerate);
		ImGui::Text("Window Resolution: %dx%d", Window::Width(), Window::Height());

		// RGBA color picker
		//ImGui::ColorEdit4("RGBA color editor", &color.x);

		// Toggle demo window button
		if (ImGui::Button("Show Demo Window")) {
			showDemoWindow = !showDemoWindow;
		}

		// Custom widgets
		ImGui::Checkbox("My cool checkbox", &isChecked);
		ImGui::DragFloat("My cool dragfloat", &dragFloatValue);
		ImGui::InputFloat("My cool float input", &floatInputValue);

	}

	// Assignment 3 UI components
	if (ImGui::CollapsingHeader("Mesh Info")) {
		for (std::shared_ptr<Mesh> mesh : meshes) { 
			// Had some help from here converting strings to char*
			// https://stackoverflow.com/questions/7352099/stdstring-to-char
			ImGui::Text(mesh->GetMeshName().c_str());
			ImGui::BulletText("Vertices: %i", mesh->GetVertexCount());
			ImGui::BulletText("Indices: %i", mesh->GetIndexCount());
			ImGui::BulletText("Triangles: %i", mesh->GetIndexCount() / 3);
		}
	}

	// Assignment 4 UI components
	if (ImGui::CollapsingHeader("Mesh Values")) {
		//ImGui::DragFloat3("Offset", offset, 0.1f);
		ImGui::ColorEdit4("Color Tint", color, 0.2f);
	}

	// I feel like there has to be a better way to do this, but I can't think of one atm
	// unsure if it warrant creating its own variables in header
	if (ImGui::CollapsingHeader("Game Entities")) {
		for (int i = 0; i < gameEntities.size(); i++) {
			ImGui::Text("Game Entity: %i", i);
			ImGui::PushID(i);

			// Get game entity transform
			std::shared_ptr<Transform> transform = gameEntities[i]->GetTransform();
			
			// Convert and store temporarily as arrays
			float position[3] = { transform->GetPosition().x, transform->GetPosition().y, transform->GetPosition().z};
			float rotation[3] = { transform->GetPitchYawRoll().x, transform->GetPitchYawRoll().y, transform->GetPitchYawRoll().z };
			float scale[3] = { transform->GetScale().x, transform->GetScale().y, transform->GetScale().z};

			// Sliders
			ImGui::DragFloat3("Position", position, 0.1f);
			ImGui::DragFloat3("Rotation (Radians)", rotation, 0.1f);
			ImGui::DragFloat3("Scale", scale, 0.1f);

			// Update transform values
			transform->SetPosition(DirectX::XMFLOAT3(position));
			transform->SetRotation(DirectX::XMFLOAT3(rotation));
			transform->SetScale(DirectX::XMFLOAT3(scale));
			ImGui::PopID();
		}
	}
	

	ImGui::End();

	// Show demo window if toggled
	if (showDemoWindow == true) {
		ImGui::ShowDemoWindow();
	}
} 

// --------------------------------------------------------
// Clear the screen, redraw everything, present to the user
// --------------------------------------------------------
void Game::Draw(float deltaTime, float totalTime)
{
	// Frame START
	// - These things should happen ONCE PER FRAME
	// - At the beginning of Game::Draw() before drawing *anything*
	{
		// Clear the back buffer (erase what's on screen) and depth buffer
		const float color[4] = { 0.4f, 0.6f, 0.75f, 0.0f };
		Graphics::Context->ClearRenderTargetView(Graphics::BackBufferRTV.Get(),	color);
		Graphics::Context->ClearDepthStencilView(Graphics::DepthBufferDSV.Get(), D3D11_CLEAR_DEPTH, 1.0f, 0);
	}

	//for (std::shared_ptr<Mesh> mesh : meshes) {
	//	mesh->Draw();
	//}
	//triangle->Draw();
	for (std::shared_ptr<GameEntity> gameEntity : gameEntities) {
		// Creating vertex shader data
		VertexShaderData vsData{};
		vsData.colorTint = DirectX::XMFLOAT4(color);
		vsData.worldMatrix = gameEntity->GetTransform()->GetWorldMatrix();

		// mapping/passing info to buffer
		D3D11_MAPPED_SUBRESOURCE map{};
		Graphics::Context->Map(constantBuffer.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &map);
		memcpy(map.pData, &vsData, sizeof(vsData));
		Graphics::Context->Unmap(constantBuffer.Get(), 0);

		gameEntity->Draw();
	}

	// DRAW ImGui UI
	{
		ImGui::Render(); // Turns this frame�s UI into renderable triangles
		ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData()); // Draws it to the scree
	}

	// Frame END
	// - These should happen exactly ONCE PER FRAME
	// - At the very end of the frame (after drawing *everything*)
	{
		// Present at the end of the frame
		bool vsync = Graphics::VsyncState();
		Graphics::SwapChain->Present(
			vsync ? 1 : 0,
			vsync ? 0 : DXGI_PRESENT_ALLOW_TEARING);

		// Re-bind back buffer and depth buffer after presenting
		Graphics::Context->OMSetRenderTargets(
			1,
			Graphics::BackBufferRTV.GetAddressOf(),
			Graphics::DepthBufferDSV.Get());
	}
}
